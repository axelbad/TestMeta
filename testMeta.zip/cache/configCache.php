<?php return array (
  'archive' => 'archive/',
  'imageCache' => 'cache/',
  'mode' => 'GDLIB',
  'jpg_compression' => 90,
  'thumbnail/width' => 400,
  'thumbnail/height' => 400,
  'thumbnail/crop' => true,
  'thumbnail/filters' => 
  array (
    0 => 'FlipHorizontal',
    1 => 'BlackAndWhite',
  ),
  'medium/width' => 400,
  'medium/height' => 400,
  'medium/crop' => true,
  'full/width' => 800,
  'full/height' => 600,
  'full/crop' => true,
  'arrayvalue' => 
  array (
    0 => 'abc',
    1 => 'def',
  ),
  'group/innergroup/value1' => 'abc',
  'group/innergroup/value2' => 'def',
  'longtext' => '
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Magna laus. Cave putes quicquam esse verius. Hoc etsi multimodis reprehendi potest, tamen accipio, quod dant. Duo Reges: constructio interrete. </p>
    ',
  'value1' => 'prova1',
  'value2' => 'prova2',
);